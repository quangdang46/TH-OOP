public class Ex3 {
    public static int Find_Remainder(int a,int b){
        return a%b;
    }
    public static void main(String[] args) {
        int a=10,b=3;
        System.out.println("Remainder:"+Find_Remainder(a,b));
    }
}
