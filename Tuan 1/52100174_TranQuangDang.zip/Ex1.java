public class Ex1 {
    public static void main(String[] args) {
        // 1. Write a program to print your name, date of birth, and student ID.
        System.out.println("Tran Quang Dang");
        System.out.println("04/06/2003");
        System.out.println("52100174");
    }
}
