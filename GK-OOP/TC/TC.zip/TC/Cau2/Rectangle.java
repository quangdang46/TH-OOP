public class Rectangle{
    private String name;
    private String color;
    private double width;
    private double length;

    public Rectangle(String name, String color, double wid, double len){
        //sinh vien code tai day
    }

    public String getName(){
        //sinh vien viet code tai day va sua lai gia tri return
        return "";
    }

    public String getColor(){
        //sinh vien viet code tai day va sua lai gia tri return
        return "";
    }

    public double getWidth(){
        //sinh vien viet code tai day va sua lai gia tri return
        return -1;
    }
    public double getLength(){
        //sinh vien viet code tai day va sua lai gia tri return
        return -1;
    }

    public void setName(String name){
        //sinh vien code tai day
    }

    public void setColor(String color){
        //sinh vien code tai day
    }

    public void setWidth(double width){
        //sinh vien code tai day
    }

    public void setLength(double length){
        //sinh vien code tai day
    }

    public double getPerimeter(){
        //sinh vien viet code tai day va sua lai gia tri return
        return -1;
    }

    public String getType(){
        //sinh vien viet code tai day va sua lai gia tri return
        return "";
    }
	
	public boolean isSquare(){
        //sinh vien viet code tai day va sua lai gia tri return
        return false;
    }

    public double calDiagonalLine(){
        //sinh vien viet code tai day va sua lai gia tri return
        return -1;
    }

    public Rectangle resize(double rate){
         //sinh vien viet code tai day va sua lai gia tri return
         return null;
    }

    public String toString(){
        //sinh vien viet code tai day va sua lai gia tri return
        return "";
    }
}