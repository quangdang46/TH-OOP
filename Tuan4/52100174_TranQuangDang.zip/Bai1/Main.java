public class Main {

    public static void main(String[] args){
        Point2D p1 = new Point2D();
        Point2D p2 = new Point2D(2,2);


        System.out.println("p1: "+p1.getX()+" "+p1.getY());
        System.out.println("p2: "+p2.getX()+" "+p2.getY());

    }

}
