public class KhachSan extends DichVuLuuTru{

    private String tenKS;
    private int soSao;
    public KhachSan(String viTri, double giaCoBan, String tenKS, int soSao){
        super(viTri, giaCoBan);
        this.tenKS = tenKS;
        this.soSao = soSao;
    }


    @Override
    public double tinhGiaThueCoBan() {
        if(this.soSao<=2){
            return this.giaCoBan+this.giaCoBan*this.tinhThue();
        }
        return this.giaCoBan * 1.1+this.giaCoBan*1.1*this.tinhThue();
    }
}